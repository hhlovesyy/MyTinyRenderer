# Phoenix Bird

## Source

[sketchfab.com/models/844ba0cf144a413ea92c779f18912042](https://sketchfab.com/models/844ba0cf144a413ea92c779f18912042)

## Author

[sketchfab.com/norberto3d](https://sketchfab.com/norberto3d)

## License

[creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/)

## Preprocessor

[scripts/phoenix.py](../../scripts/phoenix.py)

## Screenshot

![Screenshot](screenshot.gif)
